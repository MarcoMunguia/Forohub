-- V1__crear_tablas.sql
CREATE TABLE Usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correoElectronico VARCHAR(100) UNIQUE NOT NULL,
    contrasena VARCHAR(255) NOT NULL
);

CREATE TABLE Tópico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    título VARCHAR(255) NOT NULL,
    mensaje TEXT NOT NULL,
    fechaCreación TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Abierto', 'Cerrado', 'Resuelto') NOT NULL,
    autor_id INT NOT NULL,
    curso_id INT,
    FOREIGN KEY (autor_id) REFERENCES Usuario(id),
    FOREIGN KEY (curso_id) REFERENCES Curso(id)
);
