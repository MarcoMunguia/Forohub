package com.alura.forohub.service;

import com.alura.forohub.model.Topic;
import com.alura.forohub.repository.TopicRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TopicService {

    @Autowired
    private TopicRepository repository;

    public List<Topic> listAll() {
        return repository.findAll();
    }

    public Optional<Topic> getById(Long id) {
        return repository.findById(id);
    }

    public Topic save(@Valid Topic topic) {
        if (repository.existsByTitleAndMessage(topic.getTitle(), topic.getMessage())) {
            throw new IllegalArgumentException("Topic with the same title and message already exists");
        }
        return repository.save(topic);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
