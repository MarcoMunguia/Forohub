package com.alura.forohub.config;

public class CorsConfiguration {
}
