package com.alura.forohub.dto;

public class TopicResponse {
}
