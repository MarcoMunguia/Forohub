package com.alura.forohub.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class TopicCreateRequest {
    @NotBlank(message = "El título es obligatorio.")
    private String título;

    @NotBlank(message = "El mensaje es obligatorio.")
    private String mensaje;

    @NotNull(message = "El ID del autor es obligatorio.")
    private Long autorId;

    @NotNull(message = "El ID del curso es obligatorio.")
    private Long cursoId;

    // Getters y Setters
    public String getTítulo() {
        return título;
    }

    public void setTítulo(String título) {
        this.título = título;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Long getAutorId() {
        return autorId;
    }

    public void setAutorId(Long autorId) {
        this.autorId = autorId;
    }

    public Long getCursoId() {
        return cursoId;
    }

    public void setCursoId(Long cursoId) {
        this.cursoId = cursoId;
    }
}
